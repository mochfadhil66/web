# Discount Calculator Using  HTML  CSS  &  JavaScript

A Pen created on CodePen.io. Original URL: [https://codepen.io/CreativeCoder111/pen/oNdQLEP](https://codepen.io/CreativeCoder111/pen/oNdQLEP).

